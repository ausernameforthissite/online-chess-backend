create function icregexnesel(internal, oid, internal, integer) returns double precision
    language internal
as
$$icregexnesel$$;

comment on function icregexnesel(internal, oid, internal, int4) is 'restriction selectivity of case-insensitive regex non-match';

