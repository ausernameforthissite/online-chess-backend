create function gist_box_consistent(internal, box, smallint, oid, internal) returns boolean
    language internal
as
$$gist_box_consistent$$;

comment on function gist_box_consistent(internal, box, int2, oid, internal) is 'GiST support';

