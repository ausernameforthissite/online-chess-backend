create function jsonb_insert(jsonb_in jsonb, path text[], replacement jsonb, insert_after boolean DEFAULT false) returns jsonb
    language internal
as
$$jsonb_insert$$;

comment on function jsonb_insert(jsonb, _text, jsonb, bool) is 'Insert value into a jsonb';

