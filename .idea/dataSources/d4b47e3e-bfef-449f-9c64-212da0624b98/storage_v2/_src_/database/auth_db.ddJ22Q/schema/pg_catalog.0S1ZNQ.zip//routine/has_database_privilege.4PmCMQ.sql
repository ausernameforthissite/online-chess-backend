create function has_database_privilege(name, text, text) returns boolean
    language internal
as
$$has_database_privilege_name_name$$;

comment on function has_database_privilege(oid, text) is 'current user privilege on database by database oid';

