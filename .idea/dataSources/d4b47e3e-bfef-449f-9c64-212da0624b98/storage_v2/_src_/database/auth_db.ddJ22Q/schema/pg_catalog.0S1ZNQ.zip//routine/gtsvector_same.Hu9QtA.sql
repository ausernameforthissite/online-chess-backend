create function gtsvector_same(gtsvector, gtsvector, internal) returns internal
    language internal
as
$$gtsvector_same$$;

comment on function gtsvector_same(gtsvector, gtsvector, internal) is 'GiST tsvector support';

