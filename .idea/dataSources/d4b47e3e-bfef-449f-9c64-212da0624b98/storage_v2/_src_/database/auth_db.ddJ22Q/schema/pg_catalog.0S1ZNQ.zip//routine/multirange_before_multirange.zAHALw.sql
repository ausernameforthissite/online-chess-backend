create function multirange_before_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_before_multirange$$;

comment on function multirange_before_multirange(anymultirange, anymultirange) is 'implementation of << operator';

