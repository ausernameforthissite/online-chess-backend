create function interval_mi(interval, interval) returns interval
    language internal
as
$$interval_mi$$;

comment on function interval_mi(interval, interval) is 'implementation of - operator';

