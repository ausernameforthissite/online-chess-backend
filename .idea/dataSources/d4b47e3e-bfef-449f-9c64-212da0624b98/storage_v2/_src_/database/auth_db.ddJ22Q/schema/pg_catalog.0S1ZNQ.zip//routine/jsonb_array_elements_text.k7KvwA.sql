create function jsonb_array_elements_text(from_json jsonb, OUT value text) returns SETOF text
    language internal
as
$$jsonb_array_elements_text$$;

comment on function jsonb_array_elements_text(jsonb, out text) is 'elements of jsonb array';

