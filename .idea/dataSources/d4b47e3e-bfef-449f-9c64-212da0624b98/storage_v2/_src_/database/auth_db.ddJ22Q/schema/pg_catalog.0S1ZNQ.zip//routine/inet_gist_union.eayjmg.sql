create function inet_gist_union(internal, internal) returns inet
    language internal
as
$$inet_gist_union$$;

comment on function inet_gist_union(internal, internal) is 'GiST support';

