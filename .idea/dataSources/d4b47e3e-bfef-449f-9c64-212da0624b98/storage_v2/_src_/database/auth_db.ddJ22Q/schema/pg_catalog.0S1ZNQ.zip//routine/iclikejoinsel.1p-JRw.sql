create function iclikejoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$iclikejoinsel$$;

comment on function iclikejoinsel(internal, oid, internal, int2, internal) is 'join selectivity of ILIKE';

