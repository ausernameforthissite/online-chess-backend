create function enum_smaller(anyenum, anyenum) returns anyenum
    language internal
as
$$enum_smaller$$;

comment on function enum_smaller(anyenum, anyenum) is 'smaller of two';

