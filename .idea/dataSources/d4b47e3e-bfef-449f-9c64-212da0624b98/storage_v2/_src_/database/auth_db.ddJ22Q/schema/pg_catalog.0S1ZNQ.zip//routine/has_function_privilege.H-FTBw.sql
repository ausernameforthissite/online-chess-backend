create function has_function_privilege(name, text, text) returns boolean
    language internal
as
$$has_function_privilege_name_name$$;

comment on function has_function_privilege(oid, oid, text) is 'user privilege on function by user oid, function oid';

