create function jsonb_path_query_array(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns jsonb
    language internal
as
$$jsonb_path_query_array$$;

comment on function jsonb_path_query_array(jsonb, jsonpath, jsonb, bool) is 'jsonpath query wrapped into array';

