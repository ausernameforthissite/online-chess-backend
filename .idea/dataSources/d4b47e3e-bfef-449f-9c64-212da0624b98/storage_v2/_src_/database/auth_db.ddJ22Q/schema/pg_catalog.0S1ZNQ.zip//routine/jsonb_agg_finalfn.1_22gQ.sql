create function jsonb_agg_finalfn(internal) returns jsonb
    language internal
as
$$jsonb_agg_finalfn$$;

comment on function jsonb_agg_finalfn(internal) is 'jsonb aggregate final function';

