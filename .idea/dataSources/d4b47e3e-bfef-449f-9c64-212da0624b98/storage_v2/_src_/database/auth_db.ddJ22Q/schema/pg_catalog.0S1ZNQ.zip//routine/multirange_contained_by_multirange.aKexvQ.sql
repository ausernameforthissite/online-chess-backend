create function multirange_contained_by_multirange(anymultirange, anymultirange) returns boolean
    language internal
as
$$multirange_contained_by_multirange$$;

comment on function multirange_contained_by_multirange(anymultirange, anymultirange) is 'implementation of <@ operator';

