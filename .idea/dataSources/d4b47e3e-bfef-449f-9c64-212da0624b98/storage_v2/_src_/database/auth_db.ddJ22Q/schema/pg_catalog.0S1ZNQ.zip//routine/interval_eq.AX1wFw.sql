create function interval_eq(interval, interval) returns boolean
    language internal
as
$$interval_eq$$;

comment on function interval_eq(interval, interval) is 'implementation of = operator';

