create function domain_recv(internal, oid, integer) returns "any"
    language internal
as
$$domain_recv$$;

comment on function domain_recv(internal, oid, int4) is 'I/O';

