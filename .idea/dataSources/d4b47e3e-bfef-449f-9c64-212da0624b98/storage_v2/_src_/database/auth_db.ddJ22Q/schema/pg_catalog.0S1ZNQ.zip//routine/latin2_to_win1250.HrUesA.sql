create function latin2_to_win1250(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$latin2_to_win1250$$;

comment on function latin2_to_win1250(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for LATIN2 to WIN1250';

