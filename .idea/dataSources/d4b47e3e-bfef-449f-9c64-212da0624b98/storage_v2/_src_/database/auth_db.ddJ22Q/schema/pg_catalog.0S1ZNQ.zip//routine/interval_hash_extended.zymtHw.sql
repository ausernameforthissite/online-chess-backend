create function interval_hash_extended(interval, bigint) returns bigint
    language internal
as
$$interval_hash_extended$$;

comment on function interval_hash_extended(interval, int8) is 'hash';

