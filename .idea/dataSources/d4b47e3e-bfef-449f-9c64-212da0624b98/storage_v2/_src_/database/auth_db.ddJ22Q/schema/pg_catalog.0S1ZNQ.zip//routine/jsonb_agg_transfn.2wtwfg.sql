create function jsonb_agg_transfn(internal, anyelement) returns internal
    language internal
as
$$jsonb_agg_transfn$$;

comment on function jsonb_agg_transfn(internal, anyelement) is 'jsonb aggregate transition function';

