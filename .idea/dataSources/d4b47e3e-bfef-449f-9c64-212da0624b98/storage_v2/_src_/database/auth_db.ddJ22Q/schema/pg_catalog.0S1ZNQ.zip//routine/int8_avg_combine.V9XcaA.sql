create function int8_avg_combine(internal, internal) returns internal
    language internal
as
$$int8_avg_combine$$;

comment on function int8_avg_combine(internal, internal) is 'aggregate combine function';

