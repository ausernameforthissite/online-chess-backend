create function generate_subscripts(anyarray, integer) returns SETOF integer
    language internal
as
$$generate_subscripts_nodir$$;

comment on function generate_subscripts(anyarray, int4, bool) is 'array subscripts generator';

