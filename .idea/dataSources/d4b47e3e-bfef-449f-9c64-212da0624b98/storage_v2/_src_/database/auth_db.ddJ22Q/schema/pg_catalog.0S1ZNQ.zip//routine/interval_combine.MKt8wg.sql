create function interval_combine(interval[], interval[]) returns interval[]
    language internal
as
$$interval_combine$$;

comment on function interval_combine(_interval, _interval) is 'aggregate combine function';

