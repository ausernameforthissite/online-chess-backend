create function inet_spg_inner_consistent(internal, internal) returns void
    language internal
as
$$inet_spg_inner_consistent$$;

comment on function inet_spg_inner_consistent(internal, internal) is 'SP-GiST support';

