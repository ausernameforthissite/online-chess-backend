create function interval_ne(interval, interval) returns boolean
    language internal
as
$$interval_ne$$;

comment on function interval_ne(interval, interval) is 'implementation of <> operator';

