create function multirange_contained_by_range(anymultirange, anyrange) returns boolean
    language internal
as
$$multirange_contained_by_range$$;

comment on function multirange_contained_by_range(anymultirange, anyrange) is 'implementation of <@ operator';

