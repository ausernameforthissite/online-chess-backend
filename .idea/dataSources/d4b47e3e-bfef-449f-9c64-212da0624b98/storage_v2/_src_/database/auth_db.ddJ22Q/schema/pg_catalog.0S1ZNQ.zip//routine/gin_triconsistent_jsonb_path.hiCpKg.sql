create function gin_triconsistent_jsonb_path(internal, smallint, jsonb, integer, internal, internal, internal) returns "char"
    language internal
as
$$gin_triconsistent_jsonb_path$$;

comment on function gin_triconsistent_jsonb_path(internal, int2, jsonb, int4, internal, internal, internal) is 'GIN support';

