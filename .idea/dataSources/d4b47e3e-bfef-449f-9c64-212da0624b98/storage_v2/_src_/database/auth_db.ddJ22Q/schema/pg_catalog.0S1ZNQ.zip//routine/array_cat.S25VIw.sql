create function array_cat(anycompatiblearray, anycompatiblearray) returns anycompatiblearray
    language internal
as
$$array_cat$$;

comment on function array_cat(anycompatiblearray, anycompatiblearray) is 'implementation of || operator';

