create function inet_gist_same(inet, inet, internal) returns internal
    language internal
as
$$inet_gist_same$$;

comment on function inet_gist_same(inet, inet, internal) is 'GiST support';

