create function jsonb_extract_path(from_json jsonb, VARIADIC path_elems text[]) returns jsonb
    language internal
as
$$jsonb_extract_path$$;

comment on function jsonb_extract_path(jsonb, _text) is 'get value from jsonb with path elements';

