create function interval_pl_timetz(interval, time with time zone) returns time with time zone
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_timetz(interval, timetz) is 'implementation of + operator';

