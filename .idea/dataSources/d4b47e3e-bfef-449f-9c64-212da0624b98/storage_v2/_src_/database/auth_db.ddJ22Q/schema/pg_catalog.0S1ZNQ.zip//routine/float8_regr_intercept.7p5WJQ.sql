create function float8_regr_intercept(double precision[]) returns double precision
    language internal
as
$$float8_regr_intercept$$;

comment on function float8_regr_intercept(_float8) is 'aggregate final function';

