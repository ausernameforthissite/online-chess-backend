create function in_range(bigint, bigint, bigint, boolean, boolean) returns boolean
    language internal
as
$$in_range_int8_int8$$;

comment on function in_range(int2, int2, int4, bool, bool) is 'window RANGE support';

