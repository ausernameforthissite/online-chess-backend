create function gist_poly_compress(internal) returns internal
    language internal
as
$$gist_poly_compress$$;

comment on function gist_poly_compress(internal) is 'GiST support';

