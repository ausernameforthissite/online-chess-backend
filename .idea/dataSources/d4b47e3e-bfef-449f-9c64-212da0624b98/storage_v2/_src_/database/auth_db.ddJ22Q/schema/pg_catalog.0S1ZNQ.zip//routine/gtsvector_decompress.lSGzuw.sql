create function gtsvector_decompress(internal) returns internal
    language internal
as
$$gtsvector_decompress$$;

comment on function gtsvector_decompress(internal) is 'GiST tsvector support';

