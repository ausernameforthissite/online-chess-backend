create function json_to_tsvector(json, jsonb) returns tsvector
    language internal
as
$$json_to_tsvector$$;

comment on function json_to_tsvector(regconfig, json, jsonb) is 'transform specified values from json to tsvector';

