create function jsonb_exists_all(jsonb, text[]) returns boolean
    language internal
as
$$jsonb_exists_all$$;

comment on function jsonb_exists_all(jsonb, _text) is 'implementation of ?& operator';

