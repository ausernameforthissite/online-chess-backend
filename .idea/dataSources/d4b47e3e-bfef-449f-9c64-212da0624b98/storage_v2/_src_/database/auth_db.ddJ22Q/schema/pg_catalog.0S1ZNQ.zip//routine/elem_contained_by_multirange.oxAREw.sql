create function elem_contained_by_multirange(anyelement, anymultirange) returns boolean
    language internal
as
$$elem_contained_by_multirange$$;

comment on function elem_contained_by_multirange(anyelement, anymultirange) is 'implementation of <@ operator';

