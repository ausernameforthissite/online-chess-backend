create function matchingjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$matchingjoinsel$$;

comment on function matchingjoinsel(internal, oid, internal, int2, internal) is 'join selectivity for generic matching operators';

