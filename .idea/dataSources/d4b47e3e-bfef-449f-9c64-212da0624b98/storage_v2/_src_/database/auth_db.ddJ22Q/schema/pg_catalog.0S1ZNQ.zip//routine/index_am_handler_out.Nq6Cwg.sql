create function index_am_handler_out(index_am_handler) returns cstring
    language internal
as
$$index_am_handler_out$$;

comment on function index_am_handler_out(index_am_handler) is 'I/O';

