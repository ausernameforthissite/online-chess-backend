create function brin_bloom_opcinfo(internal) returns internal
    language internal
as
$$brin_bloom_opcinfo$$;

comment on function brin_bloom_opcinfo(internal) is 'BRIN bloom support';

