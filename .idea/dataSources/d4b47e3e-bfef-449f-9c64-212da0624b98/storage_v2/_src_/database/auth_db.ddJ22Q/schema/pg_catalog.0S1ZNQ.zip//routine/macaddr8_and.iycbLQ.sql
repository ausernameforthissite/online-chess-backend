create function macaddr8_and(macaddr8, macaddr8) returns macaddr8
    language internal
as
$$macaddr8_and$$;

comment on function macaddr8_and(macaddr8, macaddr8) is 'implementation of & operator';

