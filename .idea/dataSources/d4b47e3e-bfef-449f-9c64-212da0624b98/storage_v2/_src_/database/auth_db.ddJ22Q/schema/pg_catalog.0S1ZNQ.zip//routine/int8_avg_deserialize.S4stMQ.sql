create function int8_avg_deserialize(bytea, internal) returns internal
    language internal
as
$$int8_avg_deserialize$$;

comment on function int8_avg_deserialize(bytea, internal) is 'aggregate deserial function';

