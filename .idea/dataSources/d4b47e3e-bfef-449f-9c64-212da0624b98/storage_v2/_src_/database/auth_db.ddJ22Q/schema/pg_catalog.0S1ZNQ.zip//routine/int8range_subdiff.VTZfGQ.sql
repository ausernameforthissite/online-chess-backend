create function int8range_subdiff(bigint, bigint) returns double precision
    language internal
as
$$int8range_subdiff$$;

comment on function int8range_subdiff(int8, int8) is 'float8 difference of two int8 values';

