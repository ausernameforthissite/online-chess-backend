create function hashbpcharextended(character, bigint) returns bigint
    language internal
as
$$hashbpcharextended$$;

comment on function hashbpcharextended(bpchar, int8) is 'hash';

