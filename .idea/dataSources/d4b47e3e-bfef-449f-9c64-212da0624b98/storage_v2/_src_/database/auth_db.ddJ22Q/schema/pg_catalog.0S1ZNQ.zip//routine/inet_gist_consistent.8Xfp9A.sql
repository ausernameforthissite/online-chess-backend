create function inet_gist_consistent(internal, inet, smallint, oid, internal) returns boolean
    language internal
as
$$inet_gist_consistent$$;

comment on function inet_gist_consistent(internal, inet, int2, oid, internal) is 'GiST support';

