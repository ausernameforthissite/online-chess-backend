create function jsonb_contained(jsonb, jsonb) returns boolean
    language internal
as
$$jsonb_contained$$;

comment on function jsonb_contained(jsonb, jsonb) is 'implementation of <@ operator';

