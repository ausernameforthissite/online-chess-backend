create function has_database_privilege(name, text, text) returns boolean
    language internal
as
$$has_database_privilege_name_name$$;

comment on function has_database_privilege(oid, text, text) is 'user privilege on database by user oid, database name';

