create function gist_point_compress(internal) returns internal
    language internal
as
$$gist_point_compress$$;

comment on function gist_point_compress(internal) is 'GiST support';

