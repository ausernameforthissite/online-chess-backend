create function jsonb_subscript_handler(internal) returns internal
    language internal
as
$$jsonb_subscript_handler$$;

comment on function jsonb_subscript_handler(internal) is 'jsonb subscripting logic';

