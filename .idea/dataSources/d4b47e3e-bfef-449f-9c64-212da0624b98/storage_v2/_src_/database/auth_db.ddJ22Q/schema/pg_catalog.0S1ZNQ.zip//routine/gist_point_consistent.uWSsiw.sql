create function gist_point_consistent(internal, point, smallint, oid, internal) returns boolean
    language internal
as
$$gist_point_consistent$$;

comment on function gist_point_consistent(internal, point, int2, oid, internal) is 'GiST support';

