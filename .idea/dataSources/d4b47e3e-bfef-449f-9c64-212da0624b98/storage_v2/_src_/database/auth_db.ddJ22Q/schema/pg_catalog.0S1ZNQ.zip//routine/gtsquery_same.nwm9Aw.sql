create function gtsquery_same(bigint, bigint, internal) returns internal
    language internal
as
$$gtsquery_same$$;

comment on function gtsquery_same(int8, int8, internal) is 'GiST tsquery support';

