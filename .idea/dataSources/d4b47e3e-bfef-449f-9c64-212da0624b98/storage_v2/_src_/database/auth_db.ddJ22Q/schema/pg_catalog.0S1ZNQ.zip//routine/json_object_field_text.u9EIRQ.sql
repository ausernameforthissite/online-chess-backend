create function json_object_field_text(from_json json, field_name text) returns text
    language internal
as
$$json_object_field_text$$;

comment on function json_object_field_text(json, text) is 'implementation of ->> operator';

