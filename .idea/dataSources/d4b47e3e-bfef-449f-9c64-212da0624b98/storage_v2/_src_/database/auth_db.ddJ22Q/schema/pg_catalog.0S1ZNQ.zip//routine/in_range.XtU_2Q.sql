create function in_range(bigint, bigint, bigint, boolean, boolean) returns boolean
    language internal
as
$$in_range_int8_int8$$;

comment on function in_range(float4, float4, float8, bool, bool) is 'window RANGE support';

