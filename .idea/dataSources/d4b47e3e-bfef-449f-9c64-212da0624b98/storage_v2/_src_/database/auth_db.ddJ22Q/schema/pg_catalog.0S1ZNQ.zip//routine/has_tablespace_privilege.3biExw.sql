create function has_tablespace_privilege(name, text, text) returns boolean
    language internal
as
$$has_tablespace_privilege_name_name$$;

comment on function has_tablespace_privilege(oid, text) is 'current user privilege on tablespace by tablespace oid';

