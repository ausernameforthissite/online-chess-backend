create function jsonb_path_query_tz(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns SETOF jsonb
    language internal
as
$$jsonb_path_query_tz$$;

comment on function jsonb_path_query_tz(jsonb, jsonpath, jsonb, bool) is 'jsonpath query with timezone';

