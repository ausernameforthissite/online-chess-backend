create function jsonb_exists_any(jsonb, text[]) returns boolean
    language internal
as
$$jsonb_exists_any$$;

comment on function jsonb_exists_any(jsonb, _text) is 'implementation of ?| operator';

