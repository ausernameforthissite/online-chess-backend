create function hashenumextended(anyenum, bigint) returns bigint
    language internal
as
$$hashenumextended$$;

comment on function hashenumextended(anyenum, int8) is 'hash';

