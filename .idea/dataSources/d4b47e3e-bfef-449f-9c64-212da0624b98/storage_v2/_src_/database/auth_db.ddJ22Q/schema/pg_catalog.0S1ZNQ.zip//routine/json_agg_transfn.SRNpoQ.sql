create function json_agg_transfn(internal, anyelement) returns internal
    language internal
as
$$json_agg_transfn$$;

comment on function json_agg_transfn(internal, anyelement) is 'json aggregate transition function';

