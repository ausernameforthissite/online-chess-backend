create function inet_same_family(inet, inet) returns boolean
    language internal
as
$$inet_same_family$$;

comment on function inet_same_family(inet, inet) is 'are the addresses from the same family?';

