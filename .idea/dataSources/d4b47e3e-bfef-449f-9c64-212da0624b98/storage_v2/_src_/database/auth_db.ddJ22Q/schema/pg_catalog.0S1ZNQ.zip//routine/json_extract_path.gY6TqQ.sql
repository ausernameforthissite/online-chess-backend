create function json_extract_path(from_json json, VARIADIC path_elems text[]) returns json
    language internal
as
$$json_extract_path$$;

comment on function json_extract_path(json, _text) is 'get value from json with path elements';

