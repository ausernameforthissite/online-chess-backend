create function gist_circle_compress(internal) returns internal
    language internal
as
$$gist_circle_compress$$;

comment on function gist_circle_compress(internal) is 'GiST support';

