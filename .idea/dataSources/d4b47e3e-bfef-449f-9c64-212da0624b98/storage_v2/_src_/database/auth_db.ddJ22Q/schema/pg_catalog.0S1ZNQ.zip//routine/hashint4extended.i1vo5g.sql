create function hashint4extended(integer, bigint) returns bigint
    language internal
as
$$hashint4extended$$;

comment on function hashint4extended(int4, int8) is 'hash';

