create function koi8r_to_win1251(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$koi8r_to_win1251$$;

comment on function koi8r_to_win1251(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for KOI8R to WIN1251';

