create function hashoidvectorextended(oidvector, bigint) returns bigint
    language internal
as
$$hashoidvectorextended$$;

comment on function hashoidvectorextended(oidvector, int8) is 'hash';

