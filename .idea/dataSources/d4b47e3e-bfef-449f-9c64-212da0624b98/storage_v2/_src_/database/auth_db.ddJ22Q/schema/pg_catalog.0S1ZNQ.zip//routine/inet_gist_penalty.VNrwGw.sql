create function inet_gist_penalty(internal, internal, internal) returns internal
    language internal
as
$$inet_gist_penalty$$;

comment on function inet_gist_penalty(internal, internal, internal) is 'GiST support';

