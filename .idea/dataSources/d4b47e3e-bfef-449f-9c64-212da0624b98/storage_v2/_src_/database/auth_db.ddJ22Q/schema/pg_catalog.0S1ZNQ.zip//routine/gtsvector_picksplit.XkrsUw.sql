create function gtsvector_picksplit(internal, internal) returns internal
    language internal
as
$$gtsvector_picksplit$$;

comment on function gtsvector_picksplit(internal, internal) is 'GiST tsvector support';

