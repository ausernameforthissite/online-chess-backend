create function macaddr8_or(macaddr8, macaddr8) returns macaddr8
    language internal
as
$$macaddr8_or$$;

comment on function macaddr8_or(macaddr8, macaddr8) is 'implementation of | operator';

