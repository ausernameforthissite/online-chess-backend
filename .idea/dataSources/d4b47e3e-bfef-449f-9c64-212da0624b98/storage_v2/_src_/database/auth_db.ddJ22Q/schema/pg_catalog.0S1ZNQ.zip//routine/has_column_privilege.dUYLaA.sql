create function has_column_privilege(name, text, text, text) returns boolean
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(name, oid, text, text) is 'user privilege on column by username, rel oid, col name';

