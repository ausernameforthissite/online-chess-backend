create function mul_d_interval(double precision, interval) returns interval
    language internal
as
$$mul_d_interval$$;

comment on function mul_d_interval(float8, interval) is 'implementation of * operator';

