create function iso_to_win1251(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$iso_to_win1251$$;

comment on function iso_to_win1251(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for ISO-8859-5 to WIN1251';

