create function has_foreign_data_wrapper_privilege(name, text, text) returns boolean
    language internal
as
$$has_foreign_data_wrapper_privilege_name_name$$;

comment on function has_foreign_data_wrapper_privilege(name, oid, text) is 'user privilege on foreign data wrapper by username, foreign data wrapper oid';

