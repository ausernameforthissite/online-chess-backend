create function inet_spg_choose(internal, internal) returns void
    language internal
as
$$inet_spg_choose$$;

comment on function inet_spg_choose(internal, internal) is 'SP-GiST support';

