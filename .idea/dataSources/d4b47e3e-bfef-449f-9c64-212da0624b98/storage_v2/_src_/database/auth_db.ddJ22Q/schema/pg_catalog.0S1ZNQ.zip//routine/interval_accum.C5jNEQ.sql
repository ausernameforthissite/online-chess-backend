create function interval_accum(interval[], interval) returns interval[]
    language internal
as
$$interval_accum$$;

comment on function interval_accum(_interval, interval) is 'aggregate transition function';

