create function dsynonym_lexize(internal, internal, internal, internal) returns internal
    language internal
as
$$dsynonym_lexize$$;

comment on function dsynonym_lexize(internal, internal, internal, internal) is '(internal)';

