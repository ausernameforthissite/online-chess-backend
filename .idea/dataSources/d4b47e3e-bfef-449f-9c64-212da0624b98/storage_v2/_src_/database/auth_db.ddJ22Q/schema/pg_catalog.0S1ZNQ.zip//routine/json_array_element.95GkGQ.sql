create function json_array_element(from_json json, element_index integer) returns json
    language internal
as
$$json_array_element$$;

comment on function json_array_element(json, int4) is 'implementation of -> operator';

