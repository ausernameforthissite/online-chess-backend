create function hashnameextended(name, bigint) returns bigint
    language internal
as
$$hashnameextended$$;

comment on function hashnameextended(name, int8) is 'hash';

