create function gist_box_same(box, box, internal) returns internal
    language internal
as
$$gist_box_same$$;

comment on function gist_box_same(box, box, internal) is 'GiST support';

