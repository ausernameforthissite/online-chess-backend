create function float8_regr_combine(double precision[], double precision[]) returns double precision[]
    language internal
as
$$float8_regr_combine$$;

comment on function float8_regr_combine(_float8, _float8) is 'aggregate combine function';

