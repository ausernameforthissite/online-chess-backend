create function gtsquery_penalty(internal, internal, internal) returns internal
    language internal
as
$$gtsquery_penalty$$;

comment on function gtsquery_penalty(internal, internal, internal) is 'GiST tsquery support';

