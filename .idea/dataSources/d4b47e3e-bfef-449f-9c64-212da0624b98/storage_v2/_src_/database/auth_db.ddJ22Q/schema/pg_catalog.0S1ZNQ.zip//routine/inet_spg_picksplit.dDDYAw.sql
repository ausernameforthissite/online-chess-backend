create function inet_spg_picksplit(internal, internal) returns void
    language internal
as
$$inet_spg_picksplit$$;

comment on function inet_spg_picksplit(internal, internal) is 'SP-GiST support';

