create function interval_pl_date(interval, date) returns timestamp without time zone
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_date(interval, date) is 'implementation of + operator';

