create function jsonb_object_field(from_json jsonb, field_name text) returns jsonb
    language internal
as
$$jsonb_object_field$$;

comment on function jsonb_object_field(jsonb, text) is 'implementation of -> operator';

