create function gin_extract_tsvector(tsvector, internal) returns internal
    language internal
as
$$gin_extract_tsvector_2args$$;

comment on function gin_extract_tsvector(tsvector, internal, internal) is 'GIN tsvector support';

