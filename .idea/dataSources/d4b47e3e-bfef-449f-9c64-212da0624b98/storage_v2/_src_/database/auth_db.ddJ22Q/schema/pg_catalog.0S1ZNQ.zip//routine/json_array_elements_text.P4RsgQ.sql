create function json_array_elements_text(from_json json, OUT value text) returns SETOF text
    language internal
as
$$json_array_elements_text$$;

comment on function json_array_elements_text(json, out text) is 'elements of json array';

