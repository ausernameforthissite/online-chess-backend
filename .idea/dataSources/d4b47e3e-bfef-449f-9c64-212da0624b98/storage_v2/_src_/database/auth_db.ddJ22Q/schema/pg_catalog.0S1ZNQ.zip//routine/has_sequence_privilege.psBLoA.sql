create function has_sequence_privilege(name, text, text) returns boolean
    language internal
as
$$has_sequence_privilege_name_name$$;

comment on function has_sequence_privilege(oid, text) is 'current user privilege on sequence by seq oid';

