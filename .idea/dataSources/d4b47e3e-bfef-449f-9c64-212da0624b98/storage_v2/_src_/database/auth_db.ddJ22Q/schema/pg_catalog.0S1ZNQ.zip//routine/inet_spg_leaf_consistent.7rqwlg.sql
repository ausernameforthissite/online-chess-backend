create function inet_spg_leaf_consistent(internal, internal) returns boolean
    language internal
as
$$inet_spg_leaf_consistent$$;

comment on function inet_spg_leaf_consistent(internal, internal) is 'SP-GiST support';

