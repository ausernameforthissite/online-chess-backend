create function gin_consistent_jsonb(internal, smallint, jsonb, integer, internal, internal, internal, internal) returns boolean
    language internal
as
$$gin_consistent_jsonb$$;

comment on function gin_consistent_jsonb(internal, int2, jsonb, int4, internal, internal, internal, internal) is 'GIN support';

