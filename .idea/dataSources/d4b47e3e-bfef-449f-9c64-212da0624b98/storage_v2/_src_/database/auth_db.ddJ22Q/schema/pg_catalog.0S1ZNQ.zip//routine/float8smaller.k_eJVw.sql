create function float8smaller(double precision, double precision) returns double precision
    language internal
as
$$float8smaller$$;

comment on function float8smaller(float8, float8) is 'smaller of two';

