create function generate_series(integer, integer, integer) returns SETOF integer
    language internal
as
$$generate_series_step_int4$$;

comment on function generate_series(int4, int4, int4) is 'non-persistent series generator';

