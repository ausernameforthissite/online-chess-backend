create function language_handler_out(language_handler) returns cstring
    language internal
as
$$language_handler_out$$;

comment on function language_handler_out(language_handler) is 'I/O';

