create function jsonb_object_agg_finalfn(internal) returns jsonb
    language internal
as
$$jsonb_object_agg_finalfn$$;

comment on function jsonb_object_agg_finalfn(internal) is 'jsonb object aggregate final function';

