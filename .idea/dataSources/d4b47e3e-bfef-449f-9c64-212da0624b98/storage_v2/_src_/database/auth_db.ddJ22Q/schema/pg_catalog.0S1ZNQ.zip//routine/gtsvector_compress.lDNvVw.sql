create function gtsvector_compress(internal) returns internal
    language internal
as
$$gtsvector_compress$$;

comment on function gtsvector_compress(internal) is 'GiST tsvector support';

