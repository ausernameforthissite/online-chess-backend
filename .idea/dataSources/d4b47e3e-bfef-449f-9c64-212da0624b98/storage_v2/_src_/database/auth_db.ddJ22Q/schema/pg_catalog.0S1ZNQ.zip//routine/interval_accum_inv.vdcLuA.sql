create function interval_accum_inv(interval[], interval) returns interval[]
    language internal
as
$$interval_accum_inv$$;

comment on function interval_accum_inv(_interval, interval) is 'aggregate transition function';

