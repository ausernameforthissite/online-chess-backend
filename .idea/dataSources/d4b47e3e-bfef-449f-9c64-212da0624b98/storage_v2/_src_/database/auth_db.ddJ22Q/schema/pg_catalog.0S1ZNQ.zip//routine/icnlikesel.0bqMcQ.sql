create function icnlikesel(internal, oid, internal, integer) returns double precision
    language internal
as
$$icnlikesel$$;

comment on function icnlikesel(internal, oid, internal, int4) is 'restriction selectivity of NOT ILIKE';

