create function eqjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$eqjoinsel$$;

comment on function eqjoinsel(internal, oid, internal, int2, internal) is 'join selectivity of = and related operators';

