create function interval_le(interval, interval) returns boolean
    language internal
as
$$interval_le$$;

comment on function interval_le(interval, interval) is 'implementation of <= operator';

