create function gin_compare_jsonb(text, text) returns integer
    language internal
as
$$gin_compare_jsonb$$;

comment on function gin_compare_jsonb(text, text) is 'GIN support';

