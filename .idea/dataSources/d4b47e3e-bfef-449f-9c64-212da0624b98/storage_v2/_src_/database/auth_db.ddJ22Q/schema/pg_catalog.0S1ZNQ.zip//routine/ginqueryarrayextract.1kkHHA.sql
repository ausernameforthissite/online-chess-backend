create function ginqueryarrayextract(anyarray, internal, smallint, internal, internal, internal, internal) returns internal
    language internal
as
$$ginqueryarrayextract$$;

comment on function ginqueryarrayextract(anyarray, internal, int2, internal, internal, internal, internal) is 'GIN array support';

