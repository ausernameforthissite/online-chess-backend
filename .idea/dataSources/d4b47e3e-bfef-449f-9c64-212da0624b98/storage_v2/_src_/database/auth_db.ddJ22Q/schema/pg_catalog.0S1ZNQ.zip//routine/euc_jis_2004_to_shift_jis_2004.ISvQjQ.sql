create function euc_jis_2004_to_shift_jis_2004(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$euc_jis_2004_to_shift_jis_2004$$;

comment on function euc_jis_2004_to_shift_jis_2004(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for EUC_JIS_2004 to SHIFT_JIS_2004';

