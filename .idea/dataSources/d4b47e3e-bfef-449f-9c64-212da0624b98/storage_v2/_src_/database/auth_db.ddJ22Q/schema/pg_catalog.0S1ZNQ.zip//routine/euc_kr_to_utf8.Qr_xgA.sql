create function euc_kr_to_utf8(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$euc_kr_to_utf8$$;

comment on function euc_kr_to_utf8(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for EUC_KR to UTF8';

