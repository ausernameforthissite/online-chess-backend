create function dsimple_lexize(internal, internal, internal, internal) returns internal
    language internal
as
$$dsimple_lexize$$;

comment on function dsimple_lexize(internal, internal, internal, internal) is '(internal)';

