create function iso8859_to_utf8(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$iso8859_to_utf8$$;

comment on function iso8859_to_utf8(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for ISO-8859 2-16 to UTF8';

