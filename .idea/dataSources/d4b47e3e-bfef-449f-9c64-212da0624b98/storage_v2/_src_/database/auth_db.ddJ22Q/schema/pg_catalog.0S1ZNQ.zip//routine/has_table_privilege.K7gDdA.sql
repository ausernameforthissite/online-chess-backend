create function has_table_privilege(name, text, text) returns boolean
    language internal
as
$$has_table_privilege_name_name$$;

comment on function has_table_privilege(oid, oid, text) is 'user privilege on relation by user oid, rel oid';

