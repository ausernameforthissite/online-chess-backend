create function interval_larger(interval, interval) returns interval
    language internal
as
$$interval_larger$$;

comment on function interval_larger(interval, interval) is 'larger of two';

