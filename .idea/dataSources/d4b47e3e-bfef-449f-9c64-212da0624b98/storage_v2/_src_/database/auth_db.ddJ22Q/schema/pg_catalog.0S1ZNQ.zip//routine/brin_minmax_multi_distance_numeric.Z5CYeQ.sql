create function brin_minmax_multi_distance_numeric(internal, internal) returns double precision
    language internal
as
$$brin_minmax_multi_distance_numeric$$;

comment on function brin_minmax_multi_distance_numeric(internal, internal) is 'BRIN multi minmax numeric distance';

