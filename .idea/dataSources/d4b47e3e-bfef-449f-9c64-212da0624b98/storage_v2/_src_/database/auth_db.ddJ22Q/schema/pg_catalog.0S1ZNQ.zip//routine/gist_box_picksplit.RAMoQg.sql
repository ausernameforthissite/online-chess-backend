create function gist_box_picksplit(internal, internal) returns internal
    language internal
as
$$gist_box_picksplit$$;

comment on function gist_box_picksplit(internal, internal) is 'GiST support';

