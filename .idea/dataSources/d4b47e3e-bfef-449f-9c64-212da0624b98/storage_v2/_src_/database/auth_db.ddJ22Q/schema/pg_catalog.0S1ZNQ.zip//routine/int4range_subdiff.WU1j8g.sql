create function int4range_subdiff(integer, integer) returns double precision
    language internal
as
$$int4range_subdiff$$;

comment on function int4range_subdiff(int4, int4) is 'float8 difference of two int4 values';

