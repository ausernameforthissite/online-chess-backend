create function hash_record_extended(record, bigint) returns bigint
    language internal
as
$$hash_record_extended$$;

comment on function hash_record_extended(record, int8) is 'hash';

