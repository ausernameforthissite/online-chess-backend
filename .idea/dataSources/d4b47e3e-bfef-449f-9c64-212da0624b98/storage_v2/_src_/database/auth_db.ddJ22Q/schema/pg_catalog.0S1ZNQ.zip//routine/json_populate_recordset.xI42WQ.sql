create function json_populate_recordset(base anyelement, from_json json, use_json_as_text boolean DEFAULT false) returns SETOF anyelement
    language internal
as
$$json_populate_recordset$$;

comment on function json_populate_recordset(anyelement, json, bool) is 'get set of records with fields from a json array of objects';

