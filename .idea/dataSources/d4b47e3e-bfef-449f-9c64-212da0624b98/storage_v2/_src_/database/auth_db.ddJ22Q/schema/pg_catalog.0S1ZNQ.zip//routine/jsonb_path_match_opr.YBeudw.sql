create function jsonb_path_match_opr(jsonb, jsonpath) returns boolean
    language internal
as
$$jsonb_path_match_opr$$;

comment on function jsonb_path_match_opr(jsonb, jsonpath) is 'implementation of @@ operator';

