create function jsonb_array_elements(from_json jsonb, OUT value jsonb) returns SETOF jsonb
    language internal
as
$$jsonb_array_elements$$;

comment on function jsonb_array_elements(jsonb, out jsonb) is 'elements of a jsonb array';

