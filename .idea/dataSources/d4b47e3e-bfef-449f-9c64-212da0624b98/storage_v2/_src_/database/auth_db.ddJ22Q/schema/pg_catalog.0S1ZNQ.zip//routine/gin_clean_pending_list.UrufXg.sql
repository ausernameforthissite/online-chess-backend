create function gin_clean_pending_list(regclass) returns bigint
    language internal
as
$$gin_clean_pending_list$$;

comment on function gin_clean_pending_list(regclass) is 'clean up GIN pending list';

