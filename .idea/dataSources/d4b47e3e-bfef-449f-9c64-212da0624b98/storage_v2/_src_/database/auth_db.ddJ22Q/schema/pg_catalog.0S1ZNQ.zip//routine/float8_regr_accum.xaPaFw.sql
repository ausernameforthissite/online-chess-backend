create function float8_regr_accum(double precision[], double precision, double precision) returns double precision[]
    language internal
as
$$float8_regr_accum$$;

comment on function float8_regr_accum(_float8, float8, float8) is 'aggregate transition function';

