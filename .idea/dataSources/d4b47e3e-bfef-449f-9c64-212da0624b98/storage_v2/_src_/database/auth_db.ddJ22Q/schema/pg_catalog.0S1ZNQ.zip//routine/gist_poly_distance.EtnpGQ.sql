create function gist_poly_distance(internal, polygon, smallint, oid, internal) returns double precision
    language internal
as
$$gist_poly_distance$$;

comment on function gist_poly_distance(internal, polygon, int2, oid, internal) is 'GiST support';

