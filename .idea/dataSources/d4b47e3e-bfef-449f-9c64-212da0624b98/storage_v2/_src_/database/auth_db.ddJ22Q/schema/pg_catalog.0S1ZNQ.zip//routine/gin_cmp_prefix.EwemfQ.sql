create function gin_cmp_prefix(text, text, smallint, internal) returns integer
    language internal
as
$$gin_cmp_prefix$$;

comment on function gin_cmp_prefix(text, text, int2, internal) is 'GIN tsvector support';

