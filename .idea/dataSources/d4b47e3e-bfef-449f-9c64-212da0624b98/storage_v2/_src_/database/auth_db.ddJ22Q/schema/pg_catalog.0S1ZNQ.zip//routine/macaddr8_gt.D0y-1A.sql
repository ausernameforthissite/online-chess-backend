create function macaddr8_gt(macaddr8, macaddr8) returns boolean
    language internal
as
$$macaddr8_gt$$;

comment on function macaddr8_gt(macaddr8, macaddr8) is 'implementation of > operator';

