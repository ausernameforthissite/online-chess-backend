create function icregexeqsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$icregexeqsel$$;

comment on function icregexeqsel(internal, oid, internal, int4) is 'restriction selectivity of case-insensitive regex match';

