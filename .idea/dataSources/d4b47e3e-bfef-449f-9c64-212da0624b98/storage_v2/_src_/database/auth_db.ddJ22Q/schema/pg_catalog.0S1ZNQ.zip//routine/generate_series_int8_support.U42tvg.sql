create function generate_series_int8_support(internal) returns internal
    language internal
as
$$generate_series_int8_support$$;

comment on function generate_series_int8_support(internal) is 'planner support for generate_series';

