create function ginarrayextract(anyarray, internal) returns internal
    language internal
as
$$ginarrayextract_2args$$;

comment on function ginarrayextract(anyarray, internal, internal) is 'GIN array support';

