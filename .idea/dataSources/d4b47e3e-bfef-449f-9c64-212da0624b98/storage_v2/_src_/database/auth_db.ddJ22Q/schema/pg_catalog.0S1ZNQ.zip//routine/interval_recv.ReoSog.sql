create function interval_recv(internal, oid, integer) returns interval
    language internal
as
$$interval_recv$$;

comment on function interval_recv(internal, oid, int4) is 'I/O';

