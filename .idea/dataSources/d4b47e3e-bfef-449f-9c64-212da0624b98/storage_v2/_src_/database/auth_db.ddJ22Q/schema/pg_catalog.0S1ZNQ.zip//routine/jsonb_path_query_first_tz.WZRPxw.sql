create function jsonb_path_query_first_tz(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns jsonb
    language internal
as
$$jsonb_path_query_first_tz$$;

comment on function jsonb_path_query_first_tz(jsonb, jsonpath, jsonb, bool) is 'jsonpath query first item with timezone';

