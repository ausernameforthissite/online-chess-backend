create function jsonb_object_field_text(from_json jsonb, field_name text) returns text
    language internal
as
$$jsonb_object_field_text$$;

comment on function jsonb_object_field_text(jsonb, text) is 'implementation of ->> operator';

