create function daterange_canonical(daterange) returns daterange
    language internal
as
$$daterange_canonical$$;

comment on function daterange_canonical(daterange) is 'convert a date range to canonical form';

