create function gist_circle_distance(internal, circle, smallint, oid, internal) returns double precision
    language internal
as
$$gist_circle_distance$$;

comment on function gist_circle_distance(internal, circle, int2, oid, internal) is 'GiST support';

