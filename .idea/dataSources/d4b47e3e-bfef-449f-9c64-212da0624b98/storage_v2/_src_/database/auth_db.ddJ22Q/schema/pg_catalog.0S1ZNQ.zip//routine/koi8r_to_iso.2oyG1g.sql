create function koi8r_to_iso(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$koi8r_to_iso$$;

comment on function koi8r_to_iso(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for KOI8R to ISO-8859-5';

