create function has_server_privilege(name, text, text) returns boolean
    language internal
as
$$has_server_privilege_name_name$$;

comment on function has_server_privilege(name, oid, text) is 'user privilege on server by username, server oid';

