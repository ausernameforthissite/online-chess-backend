create function gtsvector_union(internal, internal) returns gtsvector
    language internal
as
$$gtsvector_union$$;

comment on function gtsvector_union(internal, internal) is 'GiST tsvector support';

