create function int8_avg_serialize(internal) returns bytea
    language internal
as
$$int8_avg_serialize$$;

comment on function int8_avg_serialize(internal) is 'aggregate serial function';

