create function gist_poly_consistent(internal, polygon, smallint, oid, internal) returns boolean
    language internal
as
$$gist_poly_consistent$$;

comment on function gist_poly_consistent(internal, polygon, int2, oid, internal) is 'GiST support';

