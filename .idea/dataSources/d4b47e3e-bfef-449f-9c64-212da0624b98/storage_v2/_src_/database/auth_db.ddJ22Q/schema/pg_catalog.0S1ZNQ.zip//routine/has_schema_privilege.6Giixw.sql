create function has_schema_privilege(name, text, text) returns boolean
    language internal
as
$$has_schema_privilege_name_name$$;

comment on function has_schema_privilege(oid, oid, text) is 'user privilege on schema by user oid, schema oid';

