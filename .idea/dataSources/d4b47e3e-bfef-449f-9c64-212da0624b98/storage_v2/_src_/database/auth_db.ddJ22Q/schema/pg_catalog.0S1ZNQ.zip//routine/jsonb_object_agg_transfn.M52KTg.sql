create function jsonb_object_agg_transfn(internal, "any", "any") returns internal
    language internal
as
$$jsonb_object_agg_transfn$$;

comment on function jsonb_object_agg_transfn(internal, any, any) is 'jsonb object aggregate transition function';

