create function heap_tableam_handler(internal) returns table_am_handler
    language internal
as
$$heap_tableam_handler$$;

comment on function heap_tableam_handler(internal) is 'row-oriented heap table access method handler';

