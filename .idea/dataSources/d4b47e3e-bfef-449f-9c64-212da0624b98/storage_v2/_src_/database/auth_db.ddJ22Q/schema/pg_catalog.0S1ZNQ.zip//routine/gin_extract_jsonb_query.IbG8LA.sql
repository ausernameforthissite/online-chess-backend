create function gin_extract_jsonb_query(jsonb, internal, smallint, internal, internal, internal, internal) returns internal
    language internal
as
$$gin_extract_jsonb_query$$;

comment on function gin_extract_jsonb_query(jsonb, internal, int2, internal, internal, internal, internal) is 'GIN support';

