create function interval_mul(interval, double precision) returns interval
    language internal
as
$$interval_mul$$;

comment on function interval_mul(interval, float8) is 'implementation of * operator';

