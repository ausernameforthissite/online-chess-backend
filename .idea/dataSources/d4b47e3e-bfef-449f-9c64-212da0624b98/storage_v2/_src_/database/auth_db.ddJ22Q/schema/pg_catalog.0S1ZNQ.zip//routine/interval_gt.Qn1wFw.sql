create function interval_gt(interval, interval) returns boolean
    language internal
as
$$interval_gt$$;

comment on function interval_gt(interval, interval) is 'implementation of > operator';

