create function matchingsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$matchingsel$$;

comment on function matchingsel(internal, oid, internal, int4) is 'restriction selectivity for generic matching operators';

