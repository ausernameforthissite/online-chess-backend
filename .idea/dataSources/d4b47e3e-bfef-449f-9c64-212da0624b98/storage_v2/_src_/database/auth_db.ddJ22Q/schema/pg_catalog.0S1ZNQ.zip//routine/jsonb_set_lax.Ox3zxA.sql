create function jsonb_set_lax(jsonb_in jsonb, path text[], replacement jsonb, create_if_missing boolean DEFAULT true, null_value_treatment text DEFAULT 'use_json_null'::text) returns jsonb
    language internal
as
$$jsonb_set_lax$$;

comment on function jsonb_set_lax(jsonb, _text, jsonb, bool, text) is 'Set part of a jsonb, handle NULL value';

