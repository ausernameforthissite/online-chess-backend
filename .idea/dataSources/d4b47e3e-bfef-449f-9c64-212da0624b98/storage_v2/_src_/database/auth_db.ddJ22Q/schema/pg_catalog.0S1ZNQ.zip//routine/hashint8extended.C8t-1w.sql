create function hashint8extended(bigint, bigint) returns bigint
    language internal
as
$$hashint8extended$$;

comment on function hashint8extended(int8, int8) is 'hash';

