create function has_tablespace_privilege(name, text, text) returns boolean
    language internal
as
$$has_tablespace_privilege_name_name$$;

comment on function has_tablespace_privilege(name, oid, text) is 'user privilege on tablespace by username, tablespace oid';

