create function json_extract_path_text(from_json json, VARIADIC path_elems text[]) returns text
    language internal
as
$$json_extract_path_text$$;

comment on function json_extract_path_text(json, _text) is 'get value from json as text with path elements';

