create function hashfloat4extended(real, bigint) returns bigint
    language internal
as
$$hashfloat4extended$$;

comment on function hashfloat4extended(float4, int8) is 'hash';

