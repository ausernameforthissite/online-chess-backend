create function interval_smaller(interval, interval) returns interval
    language internal
as
$$interval_smaller$$;

comment on function interval_smaller(interval, interval) is 'smaller of two';

