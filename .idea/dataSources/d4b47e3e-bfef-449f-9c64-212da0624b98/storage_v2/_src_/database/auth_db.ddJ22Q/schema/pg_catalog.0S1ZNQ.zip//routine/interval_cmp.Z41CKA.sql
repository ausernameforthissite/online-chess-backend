create function interval_cmp(interval, interval) returns integer
    language internal
as
$$interval_cmp$$;

comment on function interval_cmp(interval, interval) is 'less-equal-greater';

