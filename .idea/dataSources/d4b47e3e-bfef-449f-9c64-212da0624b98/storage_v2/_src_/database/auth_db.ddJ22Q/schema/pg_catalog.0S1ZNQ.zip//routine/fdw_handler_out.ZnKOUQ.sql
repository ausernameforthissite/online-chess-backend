create function fdw_handler_out(fdw_handler) returns cstring
    language internal
as
$$fdw_handler_out$$;

comment on function fdw_handler_out(fdw_handler) is 'I/O';

