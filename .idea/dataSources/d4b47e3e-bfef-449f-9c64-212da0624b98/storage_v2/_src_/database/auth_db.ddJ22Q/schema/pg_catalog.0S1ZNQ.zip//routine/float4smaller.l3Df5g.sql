create function float4smaller(real, real) returns real
    language internal
as
$$float4smaller$$;

comment on function float4smaller(float4, float4) is 'smaller of two';

