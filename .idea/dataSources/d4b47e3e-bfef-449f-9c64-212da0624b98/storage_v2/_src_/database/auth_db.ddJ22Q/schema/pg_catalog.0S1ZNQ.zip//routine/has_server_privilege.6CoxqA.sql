create function has_server_privilege(name, text, text) returns boolean
    language internal
as
$$has_server_privilege_name_name$$;

comment on function has_server_privilege(oid, text) is 'current user privilege on server by server oid';

