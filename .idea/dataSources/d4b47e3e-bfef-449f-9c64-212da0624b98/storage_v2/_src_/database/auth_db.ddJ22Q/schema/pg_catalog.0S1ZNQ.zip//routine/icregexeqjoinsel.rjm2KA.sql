create function icregexeqjoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$icregexeqjoinsel$$;

comment on function icregexeqjoinsel(internal, oid, internal, int2, internal) is 'join selectivity of case-insensitive regex match';

