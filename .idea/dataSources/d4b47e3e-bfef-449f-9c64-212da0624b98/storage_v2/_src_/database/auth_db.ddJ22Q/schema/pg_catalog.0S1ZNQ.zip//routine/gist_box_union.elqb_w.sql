create function gist_box_union(internal, internal) returns box
    language internal
as
$$gist_box_union$$;

comment on function gist_box_union(internal, internal) is 'GiST support';

