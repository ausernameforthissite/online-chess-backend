create function jsonb_path_exists(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns boolean
    language internal
as
$$jsonb_path_exists$$;

comment on function jsonb_path_exists(jsonb, jsonpath, jsonb, bool) is 'jsonpath exists test';

