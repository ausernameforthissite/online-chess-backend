create function jsonb_path_query_first(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns jsonb
    language internal
as
$$jsonb_path_query_first$$;

comment on function jsonb_path_query_first(jsonb, jsonpath, jsonb, bool) is 'jsonpath query first item';

