create function gin_extract_tsquery(tsvector, internal, smallint, internal, internal, internal, internal) returns internal
    language internal
as
$$gin_extract_tsquery$$;

comment on function gin_extract_tsquery(tsquery, internal, int2, internal, internal, internal, internal) is 'GIN tsvector support (obsolete)';

