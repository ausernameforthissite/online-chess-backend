create function jsonb_populate_recordset(anyelement, jsonb) returns SETOF anyelement
    language internal
as
$$jsonb_populate_recordset$$;

comment on function jsonb_populate_recordset(anyelement, jsonb) is 'get set of records with fields from a jsonb array of objects';

