create function jsonb_hash_extended(jsonb, bigint) returns bigint
    language internal
as
$$jsonb_hash_extended$$;

comment on function jsonb_hash_extended(jsonb, int8) is 'hash';

