create function has_language_privilege(name, text, text) returns boolean
    language internal
as
$$has_language_privilege_name_name$$;

comment on function has_language_privilege(name, text, text) is 'user privilege on language by username, language name';

