create function jsonb_path_match(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns boolean
    language internal
as
$$jsonb_path_match$$;

comment on function jsonb_path_match(jsonb, jsonpath, jsonb, bool) is 'jsonpath match';

