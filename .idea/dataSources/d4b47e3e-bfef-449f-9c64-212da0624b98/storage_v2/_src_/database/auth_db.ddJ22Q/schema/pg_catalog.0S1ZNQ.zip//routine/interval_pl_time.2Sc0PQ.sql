create function interval_pl_time(interval, time without time zone) returns time without time zone
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_time(interval, time) is 'implementation of + operator';

