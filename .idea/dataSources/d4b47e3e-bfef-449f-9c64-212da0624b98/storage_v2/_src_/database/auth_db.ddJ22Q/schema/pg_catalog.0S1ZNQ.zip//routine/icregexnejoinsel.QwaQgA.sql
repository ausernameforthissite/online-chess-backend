create function icregexnejoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$icregexnejoinsel$$;

comment on function icregexnejoinsel(internal, oid, internal, int2, internal) is 'join selectivity of case-insensitive regex non-match';

