create function gin_tsquery_consistent(internal, smallint, tsvector, integer, internal, internal, internal, internal) returns boolean
    language internal
as
$$gin_tsquery_consistent$$;

comment on function gin_tsquery_consistent(internal, int2, tsquery, int4, internal, internal) is 'GIN tsvector support (obsolete)';

