create function interval_lt(interval, interval) returns boolean
    language internal
as
$$interval_lt$$;

comment on function interval_lt(interval, interval) is 'implementation of < operator';

