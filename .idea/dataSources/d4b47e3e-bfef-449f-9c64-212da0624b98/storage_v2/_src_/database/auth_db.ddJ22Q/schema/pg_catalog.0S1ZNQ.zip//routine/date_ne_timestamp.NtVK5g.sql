create function date_ne_timestamp(date, timestamp without time zone) returns boolean
    language internal
as
$$date_ne_timestamp$$;

comment on function date_ne_timestamp(date, timestamp) is 'implementation of <> operator';

