create function ginarrayconsistent(internal, smallint, anyarray, integer, internal, internal, internal, internal) returns boolean
    language internal
as
$$ginarrayconsistent$$;

comment on function ginarrayconsistent(internal, int2, anyarray, int4, internal, internal, internal, internal) is 'GIN array support';

