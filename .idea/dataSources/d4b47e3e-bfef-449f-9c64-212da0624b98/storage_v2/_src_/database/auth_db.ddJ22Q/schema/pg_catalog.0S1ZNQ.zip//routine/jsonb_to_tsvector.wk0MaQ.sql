create function jsonb_to_tsvector(jsonb, jsonb) returns tsvector
    language internal
as
$$jsonb_to_tsvector$$;

comment on function jsonb_to_tsvector(regconfig, jsonb, jsonb) is 'transform specified values from jsonb to tsvector';

