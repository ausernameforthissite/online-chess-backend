create function generate_series(integer, integer, integer) returns SETOF integer
    language internal
as
$$generate_series_step_int4$$;

comment on function generate_series(timestamp, timestamp, interval) is 'non-persistent series generator';

