create function inet_gist_picksplit(internal, internal) returns internal
    language internal
as
$$inet_gist_picksplit$$;

comment on function inet_gist_picksplit(internal, internal) is 'GiST support';

