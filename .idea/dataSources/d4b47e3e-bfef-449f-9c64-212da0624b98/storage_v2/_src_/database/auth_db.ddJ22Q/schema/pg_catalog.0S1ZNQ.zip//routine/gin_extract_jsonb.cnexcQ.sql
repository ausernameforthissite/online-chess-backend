create function gin_extract_jsonb(jsonb, internal, internal) returns internal
    language internal
as
$$gin_extract_jsonb$$;

comment on function gin_extract_jsonb(jsonb, internal, internal) is 'GIN support';

