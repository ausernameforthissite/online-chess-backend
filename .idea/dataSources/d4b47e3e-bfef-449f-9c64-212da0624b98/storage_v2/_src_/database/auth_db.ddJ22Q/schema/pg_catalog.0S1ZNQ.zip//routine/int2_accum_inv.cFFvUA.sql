create function int2_accum_inv(internal, smallint) returns internal
    language internal
as
$$int2_accum_inv$$;

comment on function int2_accum_inv(internal, int2) is 'aggregate transition function';

