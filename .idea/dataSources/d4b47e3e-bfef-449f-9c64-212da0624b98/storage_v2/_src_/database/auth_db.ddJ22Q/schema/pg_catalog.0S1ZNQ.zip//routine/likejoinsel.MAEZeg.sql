create function likejoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$likejoinsel$$;

comment on function likejoinsel(internal, oid, internal, int2, internal) is 'join selectivity of LIKE';

