create function make_interval(years integer DEFAULT 0, months integer DEFAULT 0, weeks integer DEFAULT 0, days integer DEFAULT 0, hours integer DEFAULT 0, mins integer DEFAULT 0, secs double precision DEFAULT 0.0) returns interval
    language internal
as
$$make_interval$$;

comment on function make_interval(int4, int4, int4, int4, int4, int4, float8) is 'construct interval';

