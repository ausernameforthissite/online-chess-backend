create function dense_rank_final(internal, VARIADIC "any") returns bigint
    language internal
as
$$hypothetical_dense_rank_final$$;

comment on function dense_rank_final(internal, any) is 'aggregate final function';

