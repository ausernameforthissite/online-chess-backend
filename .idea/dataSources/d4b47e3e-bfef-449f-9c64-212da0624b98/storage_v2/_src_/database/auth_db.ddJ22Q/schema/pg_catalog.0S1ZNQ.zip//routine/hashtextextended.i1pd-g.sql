create function hashtextextended(text, bigint) returns bigint
    language internal
as
$$hashtextextended$$;

comment on function hashtextextended(text, int8) is 'hash';

