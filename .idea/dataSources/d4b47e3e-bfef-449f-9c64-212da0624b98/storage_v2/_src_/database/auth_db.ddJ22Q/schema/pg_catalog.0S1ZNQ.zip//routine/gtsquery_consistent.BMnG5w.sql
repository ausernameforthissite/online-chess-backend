create function gtsquery_consistent(internal, internal, integer, oid, internal) returns boolean
    language internal
as
$$gtsquery_consistent_oldsig$$;

comment on function gtsquery_consistent(internal, tsquery, int2, oid, internal) is 'GiST tsquery support';

