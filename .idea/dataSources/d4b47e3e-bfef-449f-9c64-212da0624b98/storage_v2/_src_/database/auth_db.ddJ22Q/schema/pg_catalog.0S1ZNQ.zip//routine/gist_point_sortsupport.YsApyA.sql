create function gist_point_sortsupport(internal) returns void
    language internal
as
$$gist_point_sortsupport$$;

comment on function gist_point_sortsupport(internal) is 'sort support';

