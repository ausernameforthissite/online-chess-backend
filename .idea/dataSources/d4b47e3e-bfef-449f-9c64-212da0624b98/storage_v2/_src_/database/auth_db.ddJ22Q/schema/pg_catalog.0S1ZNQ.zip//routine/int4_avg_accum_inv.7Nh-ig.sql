create function int4_avg_accum_inv(bigint[], integer) returns bigint[]
    language internal
as
$$int4_avg_accum_inv$$;

comment on function int4_avg_accum_inv(_int8, int4) is 'aggregate transition function';

