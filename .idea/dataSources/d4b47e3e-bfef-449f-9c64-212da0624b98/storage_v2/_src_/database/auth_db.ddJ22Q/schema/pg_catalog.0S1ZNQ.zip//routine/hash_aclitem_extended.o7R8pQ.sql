create function hash_aclitem_extended(aclitem, bigint) returns bigint
    language internal
as
$$hash_aclitem_extended$$;

comment on function hash_aclitem_extended(aclitem, int8) is 'hash';

