create function has_parameter_privilege(name, text, text) returns boolean
    language internal
as
$$has_parameter_privilege_name_name$$;

comment on function has_parameter_privilege(text, text) is 'current user privilege on parameter by parameter name';

