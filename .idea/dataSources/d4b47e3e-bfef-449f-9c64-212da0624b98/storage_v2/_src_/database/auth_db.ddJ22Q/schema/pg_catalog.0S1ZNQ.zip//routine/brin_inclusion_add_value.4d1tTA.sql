create function brin_inclusion_add_value(internal, internal, internal, internal) returns boolean
    language internal
as
$$brin_inclusion_add_value$$;

comment on function brin_inclusion_add_value(internal, internal, internal, internal) is 'BRIN inclusion support';

