create function dsnowball_lexize(internal, internal, internal, internal) returns internal
    cost 100
    language c
as
$$dsnowball_lexize$$;

