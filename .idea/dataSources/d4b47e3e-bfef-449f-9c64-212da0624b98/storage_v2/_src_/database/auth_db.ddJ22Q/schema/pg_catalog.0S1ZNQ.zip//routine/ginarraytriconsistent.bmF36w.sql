create function ginarraytriconsistent(internal, smallint, anyarray, integer, internal, internal, internal) returns "char"
    language internal
as
$$ginarraytriconsistent$$;

comment on function ginarraytriconsistent(internal, int2, anyarray, int4, internal, internal, internal) is 'GIN array support';

