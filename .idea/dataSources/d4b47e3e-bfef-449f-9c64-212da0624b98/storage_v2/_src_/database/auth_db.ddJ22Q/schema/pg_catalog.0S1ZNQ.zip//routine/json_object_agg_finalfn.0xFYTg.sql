create function json_object_agg_finalfn(internal) returns json
    language internal
as
$$json_object_agg_finalfn$$;

comment on function json_object_agg_finalfn(internal) is 'json object aggregate final function';

