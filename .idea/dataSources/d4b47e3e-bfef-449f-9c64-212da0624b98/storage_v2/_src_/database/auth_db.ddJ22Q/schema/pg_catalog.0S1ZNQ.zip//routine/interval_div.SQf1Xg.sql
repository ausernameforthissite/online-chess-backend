create function interval_div(interval, double precision) returns interval
    language internal
as
$$interval_div$$;

comment on function interval_div(interval, float8) is 'implementation of / operator';

