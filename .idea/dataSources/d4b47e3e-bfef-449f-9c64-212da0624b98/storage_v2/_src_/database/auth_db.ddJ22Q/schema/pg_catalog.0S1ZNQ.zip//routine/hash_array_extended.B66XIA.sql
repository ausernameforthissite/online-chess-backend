create function hash_array_extended(anyarray, bigint) returns bigint
    language internal
as
$$hash_array_extended$$;

comment on function hash_array_extended(anyarray, int8) is 'hash';

