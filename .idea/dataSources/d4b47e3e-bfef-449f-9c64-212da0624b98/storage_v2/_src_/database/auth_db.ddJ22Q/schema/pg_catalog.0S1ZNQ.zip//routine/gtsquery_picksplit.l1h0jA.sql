create function gtsquery_picksplit(internal, internal) returns internal
    language internal
as
$$gtsquery_picksplit$$;

comment on function gtsquery_picksplit(internal, internal) is 'GiST tsquery support';

