create function koi8u_to_utf8(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$koi8u_to_utf8$$;

comment on function koi8u_to_utf8(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for KOI8U to UTF8';

