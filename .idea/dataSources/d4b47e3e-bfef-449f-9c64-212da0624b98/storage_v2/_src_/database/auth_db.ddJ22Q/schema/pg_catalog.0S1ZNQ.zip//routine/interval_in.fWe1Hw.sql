create function interval_in(cstring, oid, integer) returns interval
    language internal
as
$$interval_in$$;

comment on function interval_in(cstring, oid, int4) is 'I/O';

