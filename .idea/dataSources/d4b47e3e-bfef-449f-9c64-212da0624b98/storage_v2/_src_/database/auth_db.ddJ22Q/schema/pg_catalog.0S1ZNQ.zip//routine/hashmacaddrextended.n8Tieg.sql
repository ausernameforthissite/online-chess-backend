create function hashmacaddrextended(macaddr, bigint) returns bigint
    language internal
as
$$hashmacaddrextended$$;

comment on function hashmacaddrextended(macaddr, int8) is 'hash';

