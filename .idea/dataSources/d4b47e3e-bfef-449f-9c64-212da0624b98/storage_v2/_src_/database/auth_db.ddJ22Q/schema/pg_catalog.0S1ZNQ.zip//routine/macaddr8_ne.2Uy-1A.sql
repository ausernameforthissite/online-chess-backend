create function macaddr8_ne(macaddr8, macaddr8) returns boolean
    language internal
as
$$macaddr8_ne$$;

comment on function macaddr8_ne(macaddr8, macaddr8) is 'implementation of <> operator';

