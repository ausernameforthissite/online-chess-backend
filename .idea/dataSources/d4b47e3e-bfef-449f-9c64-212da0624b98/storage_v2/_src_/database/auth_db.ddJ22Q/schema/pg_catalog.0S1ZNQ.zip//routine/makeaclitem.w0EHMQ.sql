create function makeaclitem(oid, oid, text, boolean) returns aclitem
    language internal
as
$$makeaclitem$$;

comment on function makeaclitem(oid, oid, text, bool) is 'make ACL item';

