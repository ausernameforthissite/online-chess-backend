create function array_smaller(anyarray, anyarray) returns anyarray
    language internal
as
$$array_smaller$$;

comment on function array_smaller(anyarray, anyarray) is 'smaller of two';

