create function euc_tw_to_big5(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$euc_tw_to_big5$$;

comment on function euc_tw_to_big5(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for EUC_TW to BIG5';

