create function json_populate_record(base anyelement, from_json json, use_json_as_text boolean DEFAULT false) returns anyelement
    language internal
as
$$json_populate_record$$;

comment on function json_populate_record(anyelement, json, bool) is 'get record fields from a json object';

