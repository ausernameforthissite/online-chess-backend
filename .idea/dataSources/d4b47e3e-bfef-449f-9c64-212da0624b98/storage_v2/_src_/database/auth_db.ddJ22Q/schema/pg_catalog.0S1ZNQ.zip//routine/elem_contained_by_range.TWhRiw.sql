create function elem_contained_by_range(anyelement, anyrange) returns boolean
    language internal
as
$$elem_contained_by_range$$;

comment on function elem_contained_by_range(anyelement, anyrange) is 'implementation of <@ operator';

