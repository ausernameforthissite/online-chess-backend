create function index_am_handler_in(cstring) returns index_am_handler
    language internal
as
$$index_am_handler_in$$;

comment on function index_am_handler_in(cstring) is 'I/O';

