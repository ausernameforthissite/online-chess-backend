create function int8inc_float8_float8(bigint, double precision, double precision) returns bigint
    language internal
as
$$int8inc_float8_float8$$;

comment on function int8inc_float8_float8(int8, float8, float8) is 'aggregate transition function';

