create function jsonb_path_exists_opr(jsonb, jsonpath) returns boolean
    language internal
as
$$jsonb_path_exists_opr$$;

comment on function jsonb_path_exists_opr(jsonb, jsonpath) is 'implementation of @? operator';

