create function interval_pl(interval, interval) returns interval
    language internal
as
$$interval_pl$$;

comment on function interval_pl(interval, interval) is 'implementation of + operator';

