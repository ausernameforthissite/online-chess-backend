create function has_any_column_privilege(name, text, text) returns boolean
    language internal
as
$$has_any_column_privilege_name_name$$;

comment on function has_any_column_privilege(oid, oid, text) is 'user privilege on any column by user oid, rel oid';

