create function enum_larger(anyenum, anyenum) returns anyenum
    language internal
as
$$enum_larger$$;

comment on function enum_larger(anyenum, anyenum) is 'larger of two';

