create function hash_numeric_extended(numeric, bigint) returns bigint
    language internal
as
$$hash_numeric_extended$$;

comment on function hash_numeric_extended(numeric, int8) is 'hash';

