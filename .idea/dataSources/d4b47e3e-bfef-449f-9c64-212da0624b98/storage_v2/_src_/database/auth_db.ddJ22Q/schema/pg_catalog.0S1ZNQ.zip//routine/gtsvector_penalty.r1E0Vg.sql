create function gtsvector_penalty(internal, internal, internal) returns internal
    language internal
as
$$gtsvector_penalty$$;

comment on function gtsvector_penalty(internal, internal, internal) is 'GiST tsvector support';

