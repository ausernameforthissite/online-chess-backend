create function jsonb_contains(jsonb, jsonb) returns boolean
    language internal
as
$$jsonb_contains$$;

comment on function jsonb_contains(jsonb, jsonb) is 'implementation of @> operator';

