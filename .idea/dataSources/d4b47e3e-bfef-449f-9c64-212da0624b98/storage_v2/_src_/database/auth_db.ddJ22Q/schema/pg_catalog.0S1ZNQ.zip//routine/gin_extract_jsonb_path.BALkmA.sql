create function gin_extract_jsonb_path(jsonb, internal, internal) returns internal
    language internal
as
$$gin_extract_jsonb_path$$;

comment on function gin_extract_jsonb_path(jsonb, internal, internal) is 'GIN support';

