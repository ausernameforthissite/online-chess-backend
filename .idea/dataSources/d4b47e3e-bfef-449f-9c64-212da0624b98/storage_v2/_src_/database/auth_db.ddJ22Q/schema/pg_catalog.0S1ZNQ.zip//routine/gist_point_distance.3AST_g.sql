create function gist_point_distance(internal, point, smallint, oid, internal) returns double precision
    language internal
as
$$gist_point_distance$$;

comment on function gist_point_distance(internal, point, int2, oid, internal) is 'GiST support';

