create function mic_to_win866(integer, integer, cstring, internal, integer, boolean) returns integer
    cost 100
    language c
as
$$mic_to_win866$$;

comment on function mic_to_win866(int4, int4, cstring, internal, int4, bool) is 'internal conversion function for MULE_INTERNAL to WIN866';

