create function has_column_privilege(name, text, text, text) returns boolean
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(text, text, text) is 'current user privilege on column by rel name, col name';

