create function gtsvector_consistent(internal, tsvector, smallint, oid, internal) returns boolean
    language internal
as
$$gtsvector_consistent$$;

comment on function gtsvector_consistent(internal, tsvector, int2, oid, internal) is 'GiST tsvector support';

