create function iclikesel(internal, oid, internal, integer) returns double precision
    language internal
as
$$iclikesel$$;

comment on function iclikesel(internal, oid, internal, int4) is 'restriction selectivity of ILIKE';

