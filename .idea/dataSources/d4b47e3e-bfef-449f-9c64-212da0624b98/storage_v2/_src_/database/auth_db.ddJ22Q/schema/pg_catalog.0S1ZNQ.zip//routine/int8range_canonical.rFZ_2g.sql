create function int8range_canonical(int8range) returns int8range
    language internal
as
$$int8range_canonical$$;

comment on function int8range_canonical(int8range) is 'convert an int8 range to canonical form';

