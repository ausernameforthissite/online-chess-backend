create function fmgr_internal_validator(oid) returns void
    language internal
as
$$fmgr_internal_validator$$;

comment on function fmgr_internal_validator(oid) is '(internal)';

