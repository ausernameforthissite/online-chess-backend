create function int8_avg_accum_inv(internal, bigint) returns internal
    language internal
as
$$int8_avg_accum_inv$$;

comment on function int8_avg_accum_inv(internal, int8) is 'aggregate transition function';

