create function has_schema_privilege(name, text, text) returns boolean
    language internal
as
$$has_schema_privilege_name_name$$;

comment on function has_schema_privilege(text, text) is 'current user privilege on schema by schema name';

