create function float8_combine(double precision[], double precision[]) returns double precision[]
    language internal
as
$$float8_combine$$;

comment on function float8_combine(_float8, _float8) is 'aggregate combine function';

