create function int4range_canonical(int4range) returns int4range
    language internal
as
$$int4range_canonical$$;

comment on function int4range_canonical(int4range) is 'convert an int4 range to canonical form';

