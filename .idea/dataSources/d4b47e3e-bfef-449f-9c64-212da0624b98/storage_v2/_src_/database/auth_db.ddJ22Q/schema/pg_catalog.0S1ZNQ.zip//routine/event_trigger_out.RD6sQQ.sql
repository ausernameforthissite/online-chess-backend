create function event_trigger_out(event_trigger) returns cstring
    language internal
as
$$event_trigger_out$$;

comment on function event_trigger_out(event_trigger) is 'I/O';

