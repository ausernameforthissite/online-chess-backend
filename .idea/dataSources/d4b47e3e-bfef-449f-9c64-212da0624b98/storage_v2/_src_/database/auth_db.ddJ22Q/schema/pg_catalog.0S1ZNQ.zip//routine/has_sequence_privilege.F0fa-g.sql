create function has_sequence_privilege(name, text, text) returns boolean
    language internal
as
$$has_sequence_privilege_name_name$$;

comment on function has_sequence_privilege(name, oid, text) is 'user privilege on sequence by username, seq oid';

