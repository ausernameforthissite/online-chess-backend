create function jsonb_delete_path(jsonb, text[]) returns jsonb
    language internal
as
$$jsonb_delete_path$$;

comment on function jsonb_delete_path(jsonb, _text) is 'implementation of #- operator';

