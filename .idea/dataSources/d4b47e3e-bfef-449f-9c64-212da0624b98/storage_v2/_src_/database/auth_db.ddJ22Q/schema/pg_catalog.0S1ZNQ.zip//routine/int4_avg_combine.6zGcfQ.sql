create function int4_avg_combine(bigint[], bigint[]) returns bigint[]
    language internal
as
$$int4_avg_combine$$;

comment on function int4_avg_combine(_int8, _int8) is 'aggregate combine function';

