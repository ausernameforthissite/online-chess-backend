create function interval_pl_timestamptz(interval, timestamp with time zone) returns timestamp with time zone
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function interval_pl_timestamptz(interval, timestamptz) is 'implementation of + operator';

