create function hash_multirange_extended(anymultirange, bigint) returns bigint
    language internal
as
$$hash_multirange_extended$$;

comment on function hash_multirange_extended(anymultirange, int8) is 'hash a multirange';

