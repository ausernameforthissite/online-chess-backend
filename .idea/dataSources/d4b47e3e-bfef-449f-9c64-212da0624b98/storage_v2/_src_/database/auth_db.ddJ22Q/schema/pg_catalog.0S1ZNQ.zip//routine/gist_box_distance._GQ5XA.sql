create function gist_box_distance(internal, box, smallint, oid, internal) returns double precision
    language internal
as
$$gist_box_distance$$;

comment on function gist_box_distance(internal, box, int2, oid, internal) is 'GiST support';

