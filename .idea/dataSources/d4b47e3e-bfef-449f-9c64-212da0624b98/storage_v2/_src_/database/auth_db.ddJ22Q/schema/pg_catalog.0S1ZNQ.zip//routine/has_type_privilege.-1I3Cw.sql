create function has_type_privilege(name, text, text) returns boolean
    language internal
as
$$has_type_privilege_name_name$$;

comment on function has_type_privilege(name, text, text) is 'user privilege on type by username, type name';

