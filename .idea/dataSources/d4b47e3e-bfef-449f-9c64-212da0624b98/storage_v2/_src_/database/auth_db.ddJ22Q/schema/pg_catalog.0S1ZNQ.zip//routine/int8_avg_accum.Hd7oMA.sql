create function int8_avg_accum(internal, bigint) returns internal
    language internal
as
$$int8_avg_accum$$;

comment on function int8_avg_accum(internal, int8) is 'aggregate transition function';

