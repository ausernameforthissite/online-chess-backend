create function hash_multirange(anymultirange) returns integer
    language internal
as
$$hash_multirange$$;

comment on function hash_multirange(anymultirange) is 'hash a multirange';

