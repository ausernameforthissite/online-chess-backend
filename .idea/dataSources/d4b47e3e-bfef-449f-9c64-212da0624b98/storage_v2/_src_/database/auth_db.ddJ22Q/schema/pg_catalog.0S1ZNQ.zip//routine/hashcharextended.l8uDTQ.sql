create function hashcharextended("char", bigint) returns bigint
    language internal
as
$$hashcharextended$$;

comment on function hashcharextended("char", int8) is 'hash';

