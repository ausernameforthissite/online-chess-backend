create function daterange_subdiff(date, date) returns double precision
    language internal
as
$$daterange_subdiff$$;

comment on function daterange_subdiff(date, date) is 'float8 difference of two date values';

