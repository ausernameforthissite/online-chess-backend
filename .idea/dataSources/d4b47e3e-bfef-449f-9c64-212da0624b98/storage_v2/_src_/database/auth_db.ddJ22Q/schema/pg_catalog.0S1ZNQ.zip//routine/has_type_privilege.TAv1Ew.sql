create function has_type_privilege(name, text, text) returns boolean
    language internal
as
$$has_type_privilege_name_name$$;

comment on function has_type_privilege(text, text) is 'current user privilege on type by type name';

