create function inet_gist_compress(internal) returns internal
    language internal
as
$$inet_gist_compress$$;

comment on function inet_gist_compress(internal) is 'GiST support';

