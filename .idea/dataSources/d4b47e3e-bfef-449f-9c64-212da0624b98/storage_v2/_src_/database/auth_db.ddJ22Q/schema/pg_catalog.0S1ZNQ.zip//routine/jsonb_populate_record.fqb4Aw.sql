create function jsonb_populate_record(anyelement, jsonb) returns anyelement
    language internal
as
$$jsonb_populate_record$$;

comment on function jsonb_populate_record(anyelement, jsonb) is 'get record fields from a jsonb object';

