create function hashmacaddr8extended(macaddr8, bigint) returns bigint
    language internal
as
$$hashmacaddr8extended$$;

comment on function hashmacaddr8extended(macaddr8, int8) is 'hash';

