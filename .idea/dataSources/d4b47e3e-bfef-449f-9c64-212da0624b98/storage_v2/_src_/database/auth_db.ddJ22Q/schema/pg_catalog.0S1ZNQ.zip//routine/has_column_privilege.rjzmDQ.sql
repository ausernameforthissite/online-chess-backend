create function has_column_privilege(name, text, text, text) returns boolean
    language internal
as
$$has_column_privilege_name_name_name$$;

comment on function has_column_privilege(oid, oid, int2, text) is 'user privilege on column by user oid, rel oid, col attnum';

