create function json_object_agg_transfn(internal, "any", "any") returns internal
    language internal
as
$$json_object_agg_transfn$$;

comment on function json_object_agg_transfn(internal, any, any) is 'json object aggregate transition function';

