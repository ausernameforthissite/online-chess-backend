create function icnlikejoinsel(internal, oid, internal, smallint, internal) returns double precision
    language internal
as
$$icnlikejoinsel$$;

comment on function icnlikejoinsel(internal, oid, internal, int2, internal) is 'join selectivity of NOT ILIKE';

