create function hash_range_extended(anyrange, bigint) returns bigint
    language internal
as
$$hash_range_extended$$;

comment on function hash_range_extended(anyrange, int8) is 'hash a range';

