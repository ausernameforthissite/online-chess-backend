create function gin_tsquery_triconsistent(internal, smallint, tsvector, integer, internal, internal, internal) returns "char"
    language internal
as
$$gin_tsquery_triconsistent$$;

comment on function gin_tsquery_triconsistent(internal, int2, tsvector, int4, internal, internal, internal) is 'GIN tsvector support';

