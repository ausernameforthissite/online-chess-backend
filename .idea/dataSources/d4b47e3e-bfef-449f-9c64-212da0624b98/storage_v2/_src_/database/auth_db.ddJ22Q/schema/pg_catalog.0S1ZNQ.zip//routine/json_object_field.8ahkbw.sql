create function json_object_field(from_json json, field_name text) returns json
    language internal
as
$$json_object_field$$;

comment on function json_object_field(json, text) is 'implementation of -> operator';

