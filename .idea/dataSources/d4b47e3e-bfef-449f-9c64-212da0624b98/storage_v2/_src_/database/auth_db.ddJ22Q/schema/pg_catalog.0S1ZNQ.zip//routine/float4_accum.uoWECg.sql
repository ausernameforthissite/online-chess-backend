create function float4_accum(double precision[], real) returns double precision[]
    language internal
as
$$float4_accum$$;

comment on function float4_accum(_float8, float4) is 'aggregate transition function';

