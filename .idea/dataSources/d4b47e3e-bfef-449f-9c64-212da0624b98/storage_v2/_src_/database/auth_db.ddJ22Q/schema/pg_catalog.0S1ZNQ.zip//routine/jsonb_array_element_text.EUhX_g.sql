create function jsonb_array_element_text(from_json jsonb, element_index integer) returns text
    language internal
as
$$jsonb_array_element_text$$;

comment on function jsonb_array_element_text(jsonb, int4) is 'implementation of ->> operator';

