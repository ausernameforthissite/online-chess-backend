create function jsonb_path_query_array_tz(target jsonb, path jsonpath, vars jsonb DEFAULT '{}'::jsonb, silent boolean DEFAULT false) returns jsonb
    language internal
as
$$jsonb_path_query_array_tz$$;

comment on function jsonb_path_query_array_tz(jsonb, jsonpath, jsonb, bool) is 'jsonpath query wrapped into array with timezone';

