create function eqsel(internal, oid, internal, integer) returns double precision
    language internal
as
$$eqsel$$;

comment on function eqsel(internal, oid, internal, int4) is 'restriction selectivity of = and related operators';

