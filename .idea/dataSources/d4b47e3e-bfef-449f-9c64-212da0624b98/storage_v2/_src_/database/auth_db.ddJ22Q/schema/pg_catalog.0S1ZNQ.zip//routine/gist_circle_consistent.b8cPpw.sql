create function gist_circle_consistent(internal, circle, smallint, oid, internal) returns boolean
    language internal
as
$$gist_circle_consistent$$;

comment on function gist_circle_consistent(internal, circle, int2, oid, internal) is 'GiST support';

