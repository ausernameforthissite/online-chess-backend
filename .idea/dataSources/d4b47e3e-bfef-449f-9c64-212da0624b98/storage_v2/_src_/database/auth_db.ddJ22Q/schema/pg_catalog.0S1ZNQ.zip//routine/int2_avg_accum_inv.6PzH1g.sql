create function int2_avg_accum_inv(bigint[], smallint) returns bigint[]
    language internal
as
$$int2_avg_accum_inv$$;

comment on function int2_avg_accum_inv(_int8, int2) is 'aggregate transition function';

