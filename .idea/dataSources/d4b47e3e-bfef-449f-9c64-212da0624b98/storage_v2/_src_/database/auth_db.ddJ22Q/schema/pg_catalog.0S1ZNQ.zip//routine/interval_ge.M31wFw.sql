create function interval_ge(interval, interval) returns boolean
    language internal
as
$$interval_ge$$;

comment on function interval_ge(interval, interval) is 'implementation of >= operator';

