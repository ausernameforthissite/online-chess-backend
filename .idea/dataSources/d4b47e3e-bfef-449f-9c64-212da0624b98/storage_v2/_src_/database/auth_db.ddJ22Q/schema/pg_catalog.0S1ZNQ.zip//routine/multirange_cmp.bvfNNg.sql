create function multirange_cmp(anymultirange, anymultirange) returns integer
    language internal
as
$$multirange_cmp$$;

comment on function multirange_cmp(anymultirange, anymultirange) is 'less-equal-greater';

