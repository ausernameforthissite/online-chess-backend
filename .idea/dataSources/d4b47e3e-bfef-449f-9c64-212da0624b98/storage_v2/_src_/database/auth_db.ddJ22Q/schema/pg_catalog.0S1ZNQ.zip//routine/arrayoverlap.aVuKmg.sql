create function arrayoverlap(anyarray, anyarray) returns boolean
    language internal
as
$$arrayoverlap$$;

comment on function arrayoverlap(anyarray, anyarray) is 'implementation of && operator';

