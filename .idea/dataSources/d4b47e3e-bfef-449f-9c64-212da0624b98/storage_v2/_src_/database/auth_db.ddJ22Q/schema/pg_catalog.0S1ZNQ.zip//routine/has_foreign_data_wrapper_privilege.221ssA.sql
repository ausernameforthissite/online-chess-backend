create function has_foreign_data_wrapper_privilege(name, text, text) returns boolean
    language internal
as
$$has_foreign_data_wrapper_privilege_name_name$$;

comment on function has_foreign_data_wrapper_privilege(text, text) is 'current user privilege on foreign data wrapper by foreign data wrapper name';

