create function dispell_lexize(internal, internal, internal, internal) returns internal
    language internal
as
$$dispell_lexize$$;

comment on function dispell_lexize(internal, internal, internal, internal) is '(internal)';

