create function gist_box_penalty(internal, internal, internal) returns internal
    language internal
as
$$gist_box_penalty$$;

comment on function gist_box_penalty(internal, internal, internal) is 'GiST support';

