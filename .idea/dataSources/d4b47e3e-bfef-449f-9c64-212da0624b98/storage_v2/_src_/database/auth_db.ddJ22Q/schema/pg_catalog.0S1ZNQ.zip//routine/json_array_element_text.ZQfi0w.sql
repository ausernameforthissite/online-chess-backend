create function json_array_element_text(from_json json, element_index integer) returns text
    language internal
as
$$json_array_element_text$$;

comment on function json_array_element_text(json, int4) is 'implementation of ->> operator';

