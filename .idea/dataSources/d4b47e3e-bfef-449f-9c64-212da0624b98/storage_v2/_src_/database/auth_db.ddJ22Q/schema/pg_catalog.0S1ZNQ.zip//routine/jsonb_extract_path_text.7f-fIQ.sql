create function jsonb_extract_path_text(from_json jsonb, VARIADIC path_elems text[]) returns text
    language internal
as
$$jsonb_extract_path_text$$;

comment on function jsonb_extract_path_text(jsonb, _text) is 'get value from jsonb as text with path elements';

