create function gtsquery_union(internal, internal) returns bigint
    language internal
as
$$gtsquery_union$$;

comment on function gtsquery_union(internal, internal) is 'GiST tsquery support';

