create function hashfloat8extended(double precision, bigint) returns bigint
    language internal
as
$$hashfloat8extended$$;

comment on function hashfloat8extended(float8, int8) is 'hash';

