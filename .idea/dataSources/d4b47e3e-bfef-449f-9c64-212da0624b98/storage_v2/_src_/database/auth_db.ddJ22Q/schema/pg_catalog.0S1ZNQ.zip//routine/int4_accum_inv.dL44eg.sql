create function int4_accum_inv(internal, integer) returns internal
    language internal
as
$$int4_accum_inv$$;

comment on function int4_accum_inv(internal, int4) is 'aggregate transition function';

