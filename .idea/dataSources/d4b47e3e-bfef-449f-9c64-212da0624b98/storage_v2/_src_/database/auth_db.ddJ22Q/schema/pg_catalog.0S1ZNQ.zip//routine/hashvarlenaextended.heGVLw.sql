create function hashvarlenaextended(internal, bigint) returns bigint
    language internal
as
$$hashvarlenaextended$$;

comment on function hashvarlenaextended(internal, int8) is 'hash';

