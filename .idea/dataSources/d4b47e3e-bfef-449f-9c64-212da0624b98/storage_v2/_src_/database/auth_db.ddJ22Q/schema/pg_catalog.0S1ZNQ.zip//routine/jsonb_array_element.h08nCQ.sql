create function jsonb_array_element(from_json jsonb, element_index integer) returns jsonb
    language internal
as
$$jsonb_array_element$$;

comment on function jsonb_array_element(jsonb, int4) is 'implementation of -> operator';

