create function bpchar(name) returns character
    language internal
as
$$name_bpchar$$;

comment on function bpchar("char") is 'convert char to char(n)';

