create function cash_div_int4(money, integer) returns money
    language internal
as
$$cash_div_int4$$;

comment on function cash_div_int4(money, int4) is 'implementation of / operator';

