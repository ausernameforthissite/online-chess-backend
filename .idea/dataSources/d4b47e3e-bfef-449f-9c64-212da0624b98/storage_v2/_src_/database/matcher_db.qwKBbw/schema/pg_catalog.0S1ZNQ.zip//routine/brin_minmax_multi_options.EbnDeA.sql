create function brin_minmax_multi_options(internal) returns void
    language internal
as
$$brin_minmax_multi_options$$;

comment on function brin_minmax_multi_options(internal) is 'BRIN multi minmax support';

