create function circle_eq(circle, circle) returns boolean
    language internal
as
$$circle_eq$$;

comment on function circle_eq(circle, circle) is 'implementation of = operator';

