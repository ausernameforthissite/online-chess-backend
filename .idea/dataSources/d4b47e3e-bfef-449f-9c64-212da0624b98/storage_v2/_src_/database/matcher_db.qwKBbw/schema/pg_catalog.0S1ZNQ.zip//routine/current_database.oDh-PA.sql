create function current_database() returns name
    language internal
as
$$current_database$$;

comment on function current_database() is 'name of the current database';

