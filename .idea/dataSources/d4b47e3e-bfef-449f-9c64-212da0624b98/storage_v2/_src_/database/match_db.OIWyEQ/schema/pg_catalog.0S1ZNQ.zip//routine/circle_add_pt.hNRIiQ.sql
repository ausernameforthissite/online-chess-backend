create function circle_add_pt(circle, point) returns circle
    language internal
as
$$circle_add_pt$$;

comment on function circle_add_pt(circle, point) is 'implementation of + operator';

