create function close_pb(point, box) returns point
    language internal
as
$$close_pb$$;

comment on function close_pb(point, box) is 'implementation of ## operator';

