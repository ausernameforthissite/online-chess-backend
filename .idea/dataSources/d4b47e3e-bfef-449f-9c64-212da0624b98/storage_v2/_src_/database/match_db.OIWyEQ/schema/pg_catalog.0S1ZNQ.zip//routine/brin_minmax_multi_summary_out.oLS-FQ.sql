create function brin_minmax_multi_summary_out(pg_brin_minmax_multi_summary) returns cstring
    language internal
as
$$brin_minmax_multi_summary_out$$;

comment on function brin_minmax_multi_summary_out(pg_brin_minmax_multi_summary) is 'I/O';

