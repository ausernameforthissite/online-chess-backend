create function clock_timestamp() returns timestamp with time zone
    language internal
as
$$clock_timestamp$$;

comment on function clock_timestamp() is 'current clock time';

