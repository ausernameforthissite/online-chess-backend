create function array_le(anyarray, anyarray) returns boolean
    language internal
as
$$array_le$$;

comment on function array_le(anyarray, anyarray) is 'implementation of <= operator';

