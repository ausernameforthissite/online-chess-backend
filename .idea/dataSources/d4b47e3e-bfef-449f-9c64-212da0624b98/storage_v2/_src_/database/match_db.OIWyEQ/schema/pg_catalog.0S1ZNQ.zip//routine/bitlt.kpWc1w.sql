create function bitlt(bit, bit) returns boolean
    language internal
as
$$bitlt$$;

comment on function bitlt(bit, bit) is 'implementation of < operator';

