create function abbrev(cidr) returns text
    language internal
as
$$cidr_abbrev$$;

comment on function abbrev(cidr) is 'abbreviated display of cidr value';

