create function bit_length(bit) returns integer
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function bit_length(bytea) is 'length in bits';

