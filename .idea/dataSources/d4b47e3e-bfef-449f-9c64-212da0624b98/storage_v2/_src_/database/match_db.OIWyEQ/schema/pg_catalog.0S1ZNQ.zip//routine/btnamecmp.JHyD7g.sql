create function btnamecmp(name, name) returns integer
    language internal
as
$$btnamecmp$$;

comment on function btnamecmp(name, name) is 'less-equal-greater';

