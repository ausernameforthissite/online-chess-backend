create function character_length(text) returns integer
    language internal
as
$$textlen$$;

comment on function character_length(text) is 'character length';

