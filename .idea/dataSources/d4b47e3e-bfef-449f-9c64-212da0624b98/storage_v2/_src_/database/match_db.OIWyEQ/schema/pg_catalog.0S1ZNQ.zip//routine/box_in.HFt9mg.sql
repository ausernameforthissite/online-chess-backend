create function box_in(cstring) returns box
    language internal
as
$$box_in$$;

comment on function box_in(cstring) is 'I/O';

