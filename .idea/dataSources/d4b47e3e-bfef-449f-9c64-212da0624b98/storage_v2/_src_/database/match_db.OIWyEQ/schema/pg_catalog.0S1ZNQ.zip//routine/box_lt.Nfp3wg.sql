create function box_lt(box, box) returns boolean
    language internal
as
$$box_lt$$;

comment on function box_lt(box, box) is 'implementation of < operator';

